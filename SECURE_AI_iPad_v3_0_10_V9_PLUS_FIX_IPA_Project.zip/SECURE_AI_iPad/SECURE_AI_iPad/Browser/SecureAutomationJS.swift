import Foundation

/// JavaScript DOM & Virtual Mouse Cursor automation engine for Bihar SECURE v2 (`secure.dord.gov.in/securev2/`).
/// - Locates heading rows directly by exact heading text (`RCC DRAIN`, `PAVER BLOCK`, etc.) + `(Analysis of Rates)`
/// - Clicks the exact leftmost `⊕` Add Item button inside the heading row (before Edit pencil & Delete trash)
/// - Locates the left-panel stacked-layers `+` icon directly between `LMR Location` and `No Appendix Added !` / headings
/// - Renders a live animated virtual mouse cursor with click ripples
enum SecureAutomationJS {
    static let engineScript: String = #"""
    (function() {
      if (window.__SECURE_AI_IPAD_V9__) return;

      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

      function ensureCursor(doc) {
        try {
          if (!doc || !doc.body) return null;
          let cur = doc.getElementById('secure-ai-virtual-cursor');
          if (!cur) {
            cur = doc.createElement('div');
            cur.id = 'secure-ai-virtual-cursor';
            cur.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 2L20 11.5L12.5 13.5L9.5 21L4 2Z" fill="#8B7BFF" stroke="#FFFFFF" stroke-width="1.8" stroke-linejoin="round"/></svg>';
            Object.assign(cur.style, {
              position: 'fixed', left: '50%', top: '50%', width: '24px', height: '24px',
              zIndex: '2147483647', pointerEvents: 'none',
              transition: 'left 0.15s ease-out, top 0.15s ease-out, opacity 0.2s',
              opacity: '0', filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.55))'
            });
            doc.body.appendChild(cur);
          }
          return cur;
        } catch (_) { return null; }
      }

      async function moveCursorAndRipple(el) {
        if (!el) return { cx: 0, cy: 0 };
        const doc = el.ownerDocument || document;
        const cur = ensureCursor(doc);
        const r = el.getBoundingClientRect();
        const cx = Math.max(4, Math.min((doc.defaultView?.innerWidth || window.innerWidth) - 4, r.left + r.width / 2));
        const cy = Math.max(4, Math.min((doc.defaultView?.innerHeight || window.innerHeight) - 4, r.top + r.height / 2));
        if (cur) {
          cur.style.opacity = '1';
          cur.style.left = `${cx}px`;
          cur.style.top = `${cy}px`;
          await sleep(160);
          const ring = doc.createElement('div');
          Object.assign(ring.style, {
            position: 'fixed', left: `${cx - 14}px`, top: `${cy - 14}px`, width: '28px', height: '28px',
            borderRadius: '50%', border: '2.5px solid #8B7BFF', background: 'rgba(139, 123, 255, 0.28)',
            zIndex: '2147483646', pointerEvents: 'none',
            transition: 'transform 0.25s ease-out, opacity 0.25s ease-out',
            transform: 'scale(0.5)', opacity: '1'
          });
          doc.body.appendChild(ring);
          requestAnimationFrame(() => { ring.style.transform = 'scale(1.6)'; ring.style.opacity = '0'; });
          setTimeout(() => { try { ring.remove(); } catch (_) {} }, 300);
        }
        return { cx, cy };
      }

      function hideCursor() {
        for (const d of getAllDocs()) {
          try { const cur = d.getElementById('secure-ai-virtual-cursor'); if (cur) cur.style.opacity = '0'; } catch (_) {}
        }
      }

      function getAllDocs() {
        const docs = [document];
        try {
          for (const f of document.querySelectorAll('iframe, frame')) {
            try { if (f.contentDocument && f.contentDocument.body) docs.push(f.contentDocument); } catch (_) {}
          }
        } catch (_) {}
        return docs;
      }

      function queryAllAcrossDocs(selector) {
        const out = [];
        for (const d of getAllDocs()) {
          try { out.push(...Array.from(d.querySelectorAll(selector))); } catch (_) {}
        }
        return out;
      }

      function isVisible(el) {
        if (!el) return false;
        const win = el.ownerDocument?.defaultView || window;
        const style = win.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) return false;
        const rect = el.getBoundingClientRect();
        return rect.width > 1 && rect.height > 1;
      }

      function getCheckboxTarget(cb) {
        if (!cb) return null;
        if (isVisible(cb)) return cb;
        const wrap = cb.closest('mat-checkbox, label, .form-check, .custom-control, .mdc-checkbox');
        return (wrap && isVisible(wrap)) ? wrap : null;
      }

      function blurKeyboard() {
        for (const d of getAllDocs()) {
          try { if (d.activeElement && typeof d.activeElement.blur === 'function') d.activeElement.blur(); } catch (_) {}
        }
      }

      function setNativeValue(el, value, shouldBlur = true) {
        if (!el) return;
        const win = el.ownerDocument?.defaultView || window;
        const str = value == null ? '' : String(value);
        const proto = el.tagName === 'TEXTAREA'
          ? win.HTMLTextAreaElement.prototype
          : (el.tagName === 'SELECT' ? win.HTMLSelectElement.prototype : win.HTMLInputElement.prototype);
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) setter.call(el, str);
        else el.value = str;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('blur', { bubbles: true }));
        if (shouldBlur) blurKeyboard();
      }

      async function clickEl(el) {
        if (!el) return false;
        try { el.scrollIntoView({ behavior: 'instant', block: 'center' }); } catch (_) {}
        const pos = await moveCursorAndRipple(el);
        const win = el.ownerDocument?.defaultView || window;
        const opts = { bubbles: true, cancelable: true, view: win, clientX: pos.cx, clientY: pos.cy };
        try { el.dispatchEvent(new PointerEvent('pointermove', opts)); } catch (_) {}
        el.dispatchEvent(new MouseEvent('mousemove', opts));
        try { el.dispatchEvent(new PointerEvent('pointerdown', opts)); } catch (_) {}
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        try { el.dispatchEvent(new PointerEvent('pointerup', opts)); } catch (_) {}
        if (typeof el.click === 'function') {
          el.click();
        } else {
          el.dispatchEvent(new MouseEvent('click', opts));
        }
        return true;
      }

      async function autoFillSecureLogin(userId, password) {
        const inputs = queryAllAcrossDocs('input').filter((el) => isVisible(el) && !el.disabled);
        const userInput = inputs.find((el) => {
          const m = `${el.placeholder || ''} ${el.name || ''} ${el.id || ''} ${el.getAttribute('formcontrolname') || ''}`.toLowerCase();
          return m.includes('user') || m.includes('login') || m.includes('email') || el.type === 'text';
        });
        const passInput = inputs.find((el) => el.type === 'password' || `${el.placeholder || ''} ${el.name || ''}`.toLowerCase().includes('pass'));
        const captchaInput = inputs.find((el) => `${el.placeholder || ''} ${el.name || ''} ${el.id || ''}`.toLowerCase().includes('captcha'));

        if (!userInput || !passInput) {
          return { ok: false, message: 'Open the SECURE Login popup first, then tap your saved account.' };
        }
        await moveCursorAndRipple(userInput);
        setNativeValue(userInput, userId, false);
        await sleep(120);
        await moveCursorAndRipple(passInput);
        setNativeValue(passInput, password, false);
        await sleep(120);
        hideCursor();
        if (captchaInput) captchaInput.focus();
        return { ok: true, message: `Filled login for ${userId}. Enter CAPTCHA and tap LOGIN.` };
      }

      function isPortalLoading() {
        const selectors = [
          '.spinner', '.loader', '.loading', '.blockUI', '.ngx-spinner-overlay',
          '.swal2-loading', '[class*="spinner"]', '[class*="loader"]', '#preloader',
          '.mat-progress-bar', '.progress-bar-animated'
        ];
        for (const sel of selectors) {
          for (const n of queryAllAcrossDocs(sel)) {
            if (isVisible(n)) return true;
          }
        }
        for (const s of queryAllAcrossDocs('div, span, p')) {
          if (s.children.length === 0 && isVisible(s)) {
            const t = (s.textContent || '').trim().toLowerCase();
            if (t === 'loading' || t === 'loading...' || t === 'please wait...') return true;
          }
        }
        return false;
      }

      async function waitForPortalIdle(minWaitMs = 700, maxWaitMs = 20000) {
        const start = Date.now();
        await sleep(minWaitMs);
        while (Date.now() - start < maxWaitMs) {
          if (!isPortalLoading()) return true;
          await sleep(250);
        }
        return false;
      }

      function findButtonByText(patterns, root = null) {
        const regexList = patterns.map((p) => (p instanceof RegExp ? p : new RegExp(p, 'i')));
        const candidates = root
          ? Array.from(root.querySelectorAll('button, a.btn, input[type="button"], input[type="submit"], [role="button"], a'))
          : queryAllAcrossDocs('button, a.btn, input[type="button"], input[type="submit"], [role="button"], a');
        for (const el of candidates) {
          if (!isVisible(el) || el.disabled) continue;
          const txt = (el.innerText || el.value || el.getAttribute('title') || el.getAttribute('aria-label') || '').trim();
          if (regexList.some((re) => re.test(txt))) return el;
        }
        return null;
      }

      function findRightPanelButtonByText(patterns) {
        const vw = window.innerWidth || 1024;
        const regexList = patterns.map((p) => (p instanceof RegExp ? p : new RegExp(p, 'i')));
        const candidates = queryAllAcrossDocs('button, a.btn, input[type="button"], input[type="submit"], [role="button"], a')
          .filter((el) => isVisible(el) && !el.disabled && el.getBoundingClientRect().left > vw * 0.35);
        for (const el of candidates) {
          const txt = (el.innerText || el.value || el.getAttribute('title') || el.getAttribute('aria-label') || '').trim();
          if (regexList.some((re) => re.test(txt))) return el;
        }
        return findButtonByText(patterns);
      }

      async function dismissSwalIfAny() {
        for (const btn of queryAllAcrossDocs('.swal2-confirm, button.confirm')) {
          if (isVisible(btn)) {
            const txt = (btn.innerText || '').trim().toLowerCase();
            if (txt === 'ok' || txt.includes('close')) {
              await clickEl(btn);
              return true;
            }
          }
        }
        return false;
      }

      async function confirmSwalDelete() {
        for (let i = 0; i < 20; i++) {
          for (const b of queryAllAcrossDocs('.swal2-confirm, button.swal2-confirm, button.btn-primary, button')) {
            if (!isVisible(b)) continue;
            const txt = (b.innerText || '').trim().toLowerCase();
            if (txt.includes('yes, delete') || txt.includes('yes delete') || (b.classList.contains('swal2-confirm') && txt.includes('yes'))) {
              await clickEl(b);
              await waitForPortalIdle(900, 20000);
              return { ok: true, message: 'Confirmed SweetAlert2 delete' };
            }
          }
          await sleep(180);
        }
        return { ok: false, message: 'SweetAlert2 delete confirmation button not found' };
      }

      function findActiveAppendixForm() {
        let best = null;
        let bestArea = Infinity;
        for (const el of queryAllAcrossDocs('div, form, section, .card, .modal-content')) {
          if (!isVisible(el)) continue;
          const txt = (el.innerText || '').toLowerCase();
          if ((txt.includes('add appendix') || txt.includes('appendix/description')) &&
              (txt.includes('heading') || txt.includes('lump sum') || txt.includes('lumpsum'))) {
            const hasAdd = !!findButtonByText([/^add$/i, /^save$/i, /add\s*appendix/i], el);
            const hasChk = el.querySelectorAll('input[type="checkbox"], [role="checkbox"], mat-checkbox').length >= 1
                        || el.querySelectorAll('input[type="text"], textarea, select').length >= 1;
            if (hasAdd && hasChk) {
              const r = el.getBoundingClientRect();
              const area = r.width * r.height;
              if (area < bestArea) {
                bestArea = area;
                best = el;
              }
            }
          }
        }
        return best;
      }

      async function openAddAppendixForm() {
        let form = findActiveAppendixForm();
        if (form) return { form, diag: 'already-open' };

        const vw = window.innerWidth || 1024;
        const vh = window.innerHeight || 768;

        // 1. Find the SMALL leaf label for "LMR Location" (never a tall outer wrapper div!)
        let lmrRect = null;
        let lmrBestArea = Infinity;
        for (const n of queryAllAcrossDocs('label, span, div, td, p, b, strong')) {
          if (!isVisible(n)) continue;
          const t = (n.textContent || '').trim();
          if (t.length > 45) continue;
          if (!t.toLowerCase().startsWith('lmr location')) continue;
          const r = n.getBoundingClientRect();
          if (r.height < 8 || r.height > 65 || r.top < 20 || r.bottom > vh * 0.55) continue;
          const area = r.width * r.height;
          if (area < lmrBestArea) {
            lmrBestArea = area;
            lmrRect = r;
          }
        }

        // Also locate "No Appendix Added" if present (strictly below the stacked-layers + bar)
        let noAppRect = null;
        for (const n of queryAllAcrossDocs('div, span, p, h5, h6')) {
          if (!isVisible(n)) continue;
          const t = (n.textContent || '').trim();
          if (t.length < 40 && t.toLowerCase().includes('no appendix added')) {
            const r = n.getBoundingClientRect();
            if (r.height < 80 && r.left < vw * 0.45) {
              noAppRect = r;
              break;
            }
          }
        }

        const baseTop = lmrRect ? Math.min(Math.max(lmrRect.bottom, 90), vh * 0.45) : 145;
        const minY = baseTop - 2;
        const maxY = noAppRect ? Math.min(noAppRect.top - 4, baseTop + 150) : Math.min(baseTop + 150, vh * 0.65);
        const maxX = vw * 0.42;

        // 2. Scan DOM elements in the white rounded top bar below LMR Location (exclude right-edge expand icon)
        const candidates = [];
        for (const el of queryAllAcrossDocs('img, svg, i, mat-icon, button, a, fa-icon, span, div')) {
          if (!isVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.top < minY || r.bottom > maxY || r.left < 8 || r.right > maxX) continue;
          if (r.width < 14 || r.width > 110 || r.height < 14 || r.height > 80) continue;
          const win = el.ownerDocument?.defaultView || window;
          const isIcon = ['IMG', 'SVG', 'I', 'MAT-ICON', 'BUTTON', 'A', 'FA-ICON'].includes(el.tagName)
            || el.getAttribute('role') === 'button'
            || win.getComputedStyle(el).cursor === 'pointer';
          if (!isIcon) continue;
          const cls = typeof el.className === 'string' ? el.className : (el.className?.baseVal || '');
          const meta = `${cls} ${el.getAttribute('title') || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
          if (meta.includes('expand') || meta.includes('full') || meta.includes('close')) continue;
          if (r.left > vw * 0.33) continue; // skip the small expand icon on the right edge of the bar
          candidates.push({ el, rect: r });
        }

        const targetX = vw * 0.21;
        candidates.sort((a, b) => Math.abs((a.rect.left + a.rect.width / 2) - targetX) - Math.abs((b.rect.left + b.rect.width / 2) - targetX));

        const tried = new Set();
        for (const c of candidates.slice(0, 6)) {
          const target = c.el.closest('button, a, [role="button"]') || c.el;
          if (tried.has(target)) continue;
          tried.add(target);
          await clickEl(target);
          for (let w = 0; w < 6; w++) {
            await sleep(160);
            form = findActiveAppendixForm();
            if (form) return { form, diag: 'dom-candidate' };
          }
        }

        // 3. Direct PC-style elementFromPoint coordinate probe right across the stacked-layers + icon
        const probeXs = [vw * 0.21, vw * 0.19, vw * 0.23];
        const probeYs = [baseTop + 34, baseTop + 48, baseTop + 22, baseTop + 62, baseTop + 76]
          .filter((y) => y > 40 && y < vh - 40);
        let lastHitTag = 'none';
        for (const doc of getAllDocs()) {
          for (const py of probeYs) {
            for (const px of probeXs) {
              let hit = null;
              try { hit = doc.elementFromPoint(px, py); } catch (_) {}
              if (!hit) continue;
              lastHitTag = `${hit.tagName}@${Math.round(px)},${Math.round(py)}`;
              const chain = [hit, hit.parentElement, hit.parentElement?.parentElement, hit.closest?.('button, a, [role="button"]')].filter(Boolean);
              for (const node of chain) {
                if (tried.has(node)) continue;
                const nr = node.getBoundingClientRect();
                if (nr.width > vw * 0.44 || nr.height > 110 || nr.top < minY - 12) continue;
                tried.add(node);
                await clickEl(node);
                for (let w = 0; w < 6; w++) {
                  await sleep(160);
                  form = findActiveAppendixForm();
                  if (form) return { form, diag: `probe-${lastHitTag}` };
                }
              }
            }
          }
        }
        return { form: null, diag: `vw=${Math.round(vw)} baseY=${Math.round(baseTop)} cand=${candidates.length} last=${lastHitTag}` };
      }

      function findHeadingRowByTextOrIndex(headingText, headingIndex) {
        const vw = window.innerWidth || 1024;
        const targetText = String(headingText || '').trim().toUpperCase();

        const allRows = [];
        const seenRows = new Set();
        for (const el of queryAllAcrossDocs('div, li, tr, mat-expansion-panel-header, button, a, p, span, h5, h6')) {
          if (!isVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.left > vw * 0.44 || r.width < 40 || r.height > 120) continue;
          const txt = (el.innerText || '').trim().toUpperCase();
          if (!txt || txt.includes('NO APPENDIX ADDED') || txt.includes('ADD APPENDIX/DESCRIPTION') || txt.includes('VB-G RAM G TOTAL')) continue;

          if (txt.includes('ANALYSIS OF RATES') || (targetText.length >= 3 && txt.includes(targetText))) {
            // Walk up to the FULL-WIDTH heading header bar (>= 30% of viewport width) so it includes [⊕, Edit, Trash] on the right!
            let row = el;
            for (let step = 0; step < 7 && row.parentElement; step++) {
              const curR = row.getBoundingClientRect();
              const pr = row.parentElement.getBoundingClientRect();
              if (curR.width >= vw * 0.30 && curR.height <= 115) {
                break;
              }
              if (pr.width <= vw * 0.46 && pr.height <= 125) {
                row = row.parentElement;
              } else {
                break;
              }
            }
            if (!seenRows.has(row)) {
              seenRows.add(row);
              allRows.push(row);
            }
          }
        }

        const filtered = allRows.filter((row) => {
          return !allRows.some((other) => other !== row && row.contains(other) && other.getBoundingClientRect().width >= vw * 0.30);
        });

        filtered.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);

        if (targetText.length >= 3) {
          const exact = filtered.find((r) => (r.innerText || '').toUpperCase().includes(targetText));
          if (exact) return exact;
        }
        return filtered[headingIndex] || filtered[filtered.length - 1] || null;
      }

      function findAddItemCandidatesInRow(row) {
        if (!row) return [];
        const rowRect = row.getBoundingClientRect();
        // The (i) info icon is on the left (~30-45% of row width).
        // The action buttons [⊕ Add Item, ✎ Edit, 🗑 Delete] are ALWAYS on the RIGHT half (> 55% of row width).
        // The collapse chevron (v) is at the far right edge (> rowRect.right - 26).
        const minLeft = rowRect.left + rowRect.width * 0.55;
        const maxRight = rowRect.right - 22;

        const out = [];
        const seen = new Set();
        const addCand = (el) => {
          const target = el.closest('button, a, [role="button"]') || el;
          if (!target || seen.has(target)) return;
          seen.add(target);
          out.push(target);
        };

        // 1. Explicit plus/add icons strictly in the right half
        for (const el of row.querySelectorAll('.fa-plus, .fa-plus-circle, .fa-circle-plus, .bi-plus, .bi-plus-circle, [title*="Add" i], [aria-label*="Add" i]')) {
          if (!isVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.left >= minLeft && r.right <= rowRect.right - 10) {
            addCand(el);
          }
        }

        // 2. Geometric action-cluster scan: leftmost small icon in [55% .. right-22px] = ⊕ (before Edit pencil & Delete trash)
        const icons = Array.from(row.querySelectorAll('button, a, svg, i, img, mat-icon, fa-icon, span, [role="button"]'))
          .filter((el) => {
            if (!isVisible(el)) return false;
            const r = el.getBoundingClientRect();
            if (r.width < 10 || r.width > 46 || r.height < 10 || r.height > 46) return false;
            if (r.left < minLeft || r.right > maxRight) return false;
            const win = el.ownerDocument?.defaultView || window;
            const clickable = ['BUTTON', 'A', 'SVG', 'I', 'IMG', 'MAT-ICON', 'FA-ICON'].includes(el.tagName)
              || el.getAttribute('role') === 'button'
              || win.getComputedStyle(el).cursor === 'pointer';
            if (!clickable) return false;
            const cls = typeof el.className === 'string' ? el.className : (el.className?.baseVal || '');
            const meta = `${cls} ${el.getAttribute('title') || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
            if (meta.includes('info') || meta.includes('exclamation') || meta.includes('trash') || meta.includes('delete') || meta.includes('edit') || meta.includes('pencil') || meta.includes('chevron') || meta.includes('angle') || meta.includes('caret') || meta.includes('down') || meta.includes('up')) {
              return false;
            }
            return true;
          })
          .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);

        for (const ic of icons) addCand(ic);
        return out;
      }

      function findAddItemButtonInRow(row) {
        const cands = findAddItemCandidatesInRow(row);
        return cands.length > 0 ? cands[0] : null;
      }

      async function addHeading(headingText) {
        await dismissSwalIfAny();
        const opened = await openAddAppendixForm();
        const form = opened && opened.form;
        if (!form) {
          return { ok: false, message: `Could not open "Add Appendix/Description" (${opened?.diag || ''}). Tap the stacked-layers + icon once, then press Resume.` };
        }

        const checkboxes = Array.from(form.querySelectorAll('input[type="checkbox"]'))
          .filter((cb) => !!getCheckboxTarget(cb))
          .sort((a, b) => getCheckboxTarget(a).getBoundingClientRect().top - getCheckboxTarget(b).getBoundingClientRect().top);

        if (checkboxes.length >= 1 && !checkboxes[0].checked) {
          await clickEl(getCheckboxTarget(checkboxes[0]));
          await sleep(300);
        }

        const inputs = Array.from(form.querySelectorAll('input[type="text"], input:not([type]), textarea'))
          .filter((el) => isVisible(el) && !el.disabled && !el.readOnly);
        const headInput = inputs.find((el) => {
          const meta = `${el.placeholder || ''} ${el.name || ''} ${el.id || ''}`.toLowerCase();
          return meta.includes('analysis') || meta.includes('rate') || meta.includes('head') || meta.includes('desc');
        }) || inputs[0];

        if (!headInput) {
          return { ok: false, message: 'Heading text input not found inside Add Appendix/Description.' };
        }

        await moveCursorAndRipple(headInput);
        setNativeValue(headInput, headingText);
        await sleep(220);

        const addBtn = findButtonByText([/^add$/i, /save/i, /submit/i], form);
        if (!addBtn) {
          return { ok: false, message: '"Add" button not found inside Add Appendix/Description.' };
        }
        await clickEl(addBtn);
        await waitForPortalIdle(1000, 20000);
        await dismissSwalIfAny();
        blurKeyboard();
        return { ok: true, message: `Added heading: ${headingText}` };
      }

      async function addItem(headingIndex, headingText, code, isTM) {
        await dismissSwalIfAny();
        const row = findHeadingRowByTextOrIndex(headingText, headingIndex);
        if (!row) {
          return { ok: false, message: `Heading "${headingText}" (#${headingIndex + 1}) not found in left panel.` };
        }

        const vw = window.innerWidth || 1024;
        const findRightSearchBox = () => {
          const searchInputs = queryAllAcrossDocs('input[type="text"], input[type="search"], input:not([type])')
            .filter((el) => isVisible(el) && !el.disabled && !el.readOnly && el.getBoundingClientRect().left > vw * 0.38);
          return searchInputs.find((el) => {
            const meta = `${el.placeholder || ''} ${el.name || ''} ${el.id || ''}`.toLowerCase();
            return meta.includes('spec') || meta.includes('search') || meta.includes('code') || meta.includes('activity') || meta.includes('item');
          }) || searchInputs[0] || null;
        };

        const findRightSubheadSelect = () => {
          const selects = queryAllAcrossDocs('select')
            .filter((s) => isVisible(s) && !s.disabled && s.getBoundingClientRect().left > vw * 0.38);
          return selects.find((s) => {
            const txt = Array.from(s.options).map((o) => o.text).join(' ').toLowerCase();
            return txt.includes('sub head') || txt.includes('subhead') || txt.includes('mgnrega') || txt.includes('54 -') || txt.includes('earth');
          }) || selects[0] || null;
        };

        const plusCands = findAddItemCandidatesInRow(row);
        if (plusCands.length === 0) {
          return { ok: false, message: `Could not find ⊕ Add Item button on heading "${headingText}".` };
        }

        let searchBox = null;
        let subheadSelect = null;
        for (const cand of plusCands.slice(0, 3)) {
          await clickEl(cand);
          await waitForPortalIdle(700, 12000);
          for (let w = 0; w < 6; w++) {
            subheadSelect = findRightSubheadSelect();
            searchBox = findRightSearchBox();
            if (searchBox || subheadSelect) break;
            await sleep(200);
          }
          if (searchBox || subheadSelect) break;
        }

        if (subheadSelect) {
          const chapter = String(code).split('.')[0].trim();
          let chosen = null;
          for (const opt of Array.from(subheadSelect.options)) {
            const t = (opt.text || '').trim();
            if (isTM && t.toUpperCase().includes('54') && t.toUpperCase().includes('TM')) { chosen = opt; break; }
            if (!isTM && chapter === '54' && t.toUpperCase().includes('54') && !t.toUpperCase().includes('TM') && t.toLowerCase().includes('bihar')) { chosen = opt; break; }
            if (chapter !== '54' && t.startsWith(chapter)) { chosen = opt; break; }
          }
          if (chosen && subheadSelect.value !== chosen.value) {
            await moveCursorAndRipple(subheadSelect);
            subheadSelect.value = chosen.value;
            subheadSelect.dispatchEvent(new Event('input', { bubbles: true }));
            subheadSelect.dispatchEvent(new Event('change', { bubbles: true }));
            await waitForPortalIdle(850, 15000);
          }
        }

        if (!searchBox) searchBox = findRightSearchBox();
        if (!searchBox) {
          return { ok: false, message: `Specification/Activity search box not found for ${code}.` };
        }
        await moveCursorAndRipple(searchBox);
        setNativeValue(searchBox, code);
        try { searchBox.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true })); } catch (_) {}
        await sleep(250);

        const searchBtn = findRightPanelButtonByText([/search/i, /find/i, /^go$/i]);
        if (searchBtn) {
          await clickEl(searchBtn);
          await waitForPortalIdle(850, 15000);
        }

        const codeUpper = String(code).trim().toUpperCase();
        let matchedRow = null;
        for (let w = 0; w < 10; w++) {
          const rows = queryAllAcrossDocs('tr, .list-group-item, .search-result-row, div')
            .filter((r) => isVisible(r) && r.getBoundingClientRect().left > vw * 0.35 && r.getBoundingClientRect().height < 240 && r.querySelector('input[type="checkbox"]'));
          matchedRow = rows.find((r) => (r.innerText || '').toUpperCase().includes(codeUpper));
          if (matchedRow) break;
          await sleep(250);
        }

        if (!matchedRow) {
          const cancelBtn = findRightPanelButtonByText([/cancel/i, /close/i]);
          if (cancelBtn) await clickEl(cancelBtn);
          await sleep(300);
          return { ok: true, skipped: true, message: `Code ${code} not in search results (already present). Closed cleanly.` };
        }

        const chk = matchedRow.querySelector('input[type="checkbox"]');
        if (chk && !chk.checked) {
          await clickEl(getCheckboxTarget(chk) || chk);
          await sleep(220);
        }

        const saveSpecBtn = findRightPanelButtonByText([/save/i, /add\s*selected/i, /add\s*item/i, /^add$/i, /submit/i]);
        if (!saveSpecBtn) {
          return { ok: false, message: `Save/Add button not found after selecting ${code}.` };
        }
        await clickEl(saveSpecBtn);
        await waitForPortalIdle(1000, 20000);
        await dismissSwalIfAny();
        blurKeyboard();
        return { ok: true, message: `Added SOR item ${code}` };
      }

      async function fillMeasurements(headingIndex, headingText, code, rowsData) {
        await dismissSwalIfAny();
        const row = findHeadingRowByTextOrIndex(headingText, headingIndex);
        if (!row) {
          return { ok: false, message: `Heading "${headingText}" not found for measurements of ${code}.` };
        }

        const container = row.parentElement || row;
        const codeUpper = String(code).toUpperCase();
        let itemNode = Array.from(container.querySelectorAll('div, tr, li, a, span')).find((n) => isVisible(n) && (n.innerText || '').toUpperCase().includes(codeUpper) && n.getBoundingClientRect().height < 140);
        if (!itemNode) {
          await clickEl(row);
          await sleep(500);
          itemNode = Array.from(container.querySelectorAll('div, tr, li, a, span')).find((n) => isVisible(n) && (n.innerText || '').toUpperCase().includes(codeUpper) && n.getBoundingClientRect().height < 140);
        }
        if (!itemNode) {
          itemNode = Array.from(container.querySelectorAll('div, tr, li')).find((n) => isVisible(n) && ((n.innerText || '').includes('₹ 0') || (n.innerText || '').includes('0.00')) && n.getBoundingClientRect().height < 140);
        }
        if (itemNode) {
          const measBtn = itemNode.querySelector('button[title*="Meas"], a[title*="Meas"], .fa-plus, .fa-calculator, .fa-edit') || itemNode;
          await clickEl(measBtn);
          await waitForPortalIdle(800, 15000);
        }

        for (let rIdx = 0; rIdx < rowsData.length; rIdx++) {
          const rData = rowsData[rIdx];
          if (rIdx > 0 || rData.isDeduction) {
            const addRowBtn = rData.isDeduction
              ? findButtonByText([/add\s*deduct/i, /deduction/i])
              : findButtonByText([/add\s*measurement/i, /add\s*row/i, /\+\s*add/i]);
            if (addRowBtn) {
              await clickEl(addRowBtn);
              await sleep(300);
            }
          }

          const trs = queryAllAcrossDocs('table tbody tr').filter((tr) => {
            return isVisible(tr) && tr.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"])').length >= 3;
          });
          const targetTr = trs[trs.length - 1];
          if (!targetTr) {
            return { ok: false, message: `Measurement input row not found for ${code} (row ${rIdx + 1}).` };
          }
          const inputs = Array.from(targetTr.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]), textarea'))
            .filter((el) => isVisible(el) && !el.disabled && !el.readOnly);

          const values = [rData.desc || '', rData.no || '1', rData.l || '', rData.b || '', rData.d || '', rData.cf || ''];
          for (let ci = 0; ci < Math.min(inputs.length, values.length); ci++) {
            if (values[ci] !== '') {
              setNativeValue(inputs[ci], values[ci]);
              await sleep(50);
            }
          }
        }

        const saveBtn = findRightPanelButtonByText([/save\s*measurement/i, /^save$/i, /update/i]);
        if (!saveBtn) {
          return { ok: false, message: `Save Measurements button not found for ${code}.` };
        }
        await clickEl(saveBtn);
        await waitForPortalIdle(1000, 20000);
        await dismissSwalIfAny();
        blurKeyboard();
        return { ok: true, message: `Saved ${rowsData.length} measurement row(s) for ${code}` };
      }

      async function addLumpSum(keyword, customDesc, amount) {
        await dismissSwalIfAny();
        const opened = await openAddAppendixForm();
        const form = opened && opened.form;
        if (!form) {
          return { ok: false, message: `Could not open Add Appendix/Description for Lump Sum (${opened?.diag || ''}).` };
        }

        const checkboxes = Array.from(form.querySelectorAll('input[type="checkbox"]'))
          .filter((cb) => !!getCheckboxTarget(cb))
          .sort((a, b) => getCheckboxTarget(a).getBoundingClientRect().top - getCheckboxTarget(b).getBoundingClientRect().top);

        let lumpChk = checkboxes.find((cb) => {
          const labelTxt = (cb.closest('label, mat-checkbox, .form-check')?.innerText || cb.parentElement?.innerText || '').toLowerCase();
          return labelTxt.includes('lump') && !labelTxt.includes('heading');
        }) || (checkboxes.length >= 2 ? checkboxes[checkboxes.length - 1] : checkboxes[0]);

        if (lumpChk && !lumpChk.checked) {
          await clickEl(getCheckboxTarget(lumpChk));
          await sleep(450);
        }

        const selects = Array.from(form.querySelectorAll('select')).filter((s) => isVisible(s) && !s.disabled);
        const lumpSelect = selects.find((s) => {
          const txt = Array.from(s.options).map((o) => o.text).join(' ').toLowerCase();
          return txt.includes('lump') || txt.includes('conveyance') || txt.includes('miscellaneous') || txt.includes('display board');
        }) || selects[0];

        if (!lumpSelect) {
          return { ok: false, message: 'Lump sum Type dropdown not found.' };
        }

        const kwLow = String(keyword || 'Miscellaneous').toLowerCase();
        const opt = Array.from(lumpSelect.options).find((o) => (o.text || '').toLowerCase().includes(kwLow))
          || Array.from(lumpSelect.options).find((o) => (o.text || '').toLowerCase().includes('miscellaneous'));
        if (opt) {
          await moveCursorAndRipple(lumpSelect);
          lumpSelect.value = opt.value;
          lumpSelect.dispatchEvent(new Event('change', { bubbles: true }));
          await sleep(500);
        }

        const inputs = Array.from(form.querySelectorAll('input[type="text"], input[type="number"], input:not([type]), textarea'))
          .filter((el) => isVisible(el) && !el.disabled && !el.readOnly);
        const descInput = inputs.find((el) => {
          const meta = `${el.placeholder || ''} ${el.name || ''} ${el.id || ''}`.toLowerCase();
          return meta.includes('desc') && !meta.includes('head') && !meta.includes('analysis');
        });
        if (descInput && customDesc) {
          setNativeValue(descInput, customDesc);
          await sleep(150);
        }

        const amtInput = inputs.find((el) => {
          const meta = `${el.placeholder || ''} ${el.name || ''} ${el.id || ''}`.toLowerCase();
          return meta.includes('amount') || meta.includes('amt') || meta.includes('cost') || el.type === 'number';
        }) || inputs[inputs.length - 1];

        if (!amtInput) {
          return { ok: false, message: 'Lump sum amount input not found.' };
        }
        await moveCursorAndRipple(amtInput);
        setNativeValue(amtInput, String(amount));
        await sleep(200);

        const saveBtn = findButtonByText([/^add$/i, /add\s*lump/i, /save/i], form);
        if (!saveBtn) {
          return { ok: false, message: '"Add" button not found for Lump Sum.' };
        }
        await clickEl(saveBtn);
        await waitForPortalIdle(950, 20000);
        await dismissSwalIfAny();
        blurKeyboard();
        return { ok: true, message: `Added Lump Sum: ${keyword} (₹${amount})` };
      }

      function scrapeCurrentEstimate() {
        const vw = window.innerWidth;
        const rows = [];
        for (const el of queryAllAcrossDocs('div, li, tr')) {
          if (!isVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.left > vw * 0.45 || r.height > 120) continue;
          const txt = (el.innerText || '').trim();
          if (txt.includes('Analysis of Rates') && el.querySelectorAll('svg, i, img, button').length >= 2) {
            rows.push(el);
          }
        }
        const headings = rows.map((row, idx) => {
          const rawTitle = (row.innerText || '').split('\n')[0].trim();
          const container = row.parentElement || row;
          const items = [];
          const codeRe = /\b(\d{1,2}(?:\.TM)?(?:\.[A-Za-z0-9]+){2,6})\b/gi;
          const text = container.innerText || '';
          const seen = new Set();
          let m;
          while ((m = codeRe.exec(text)) !== null) {
            const c = m[1].toUpperCase();
            if (!seen.has(c)) {
              seen.add(c);
              items.push({ code: c, description: c, quantity: 0, amount: 0 });
            }
          }
          return { index: idx, text: rawTitle, items };
        });

        const lumpSums = [];
        const bodyText = document.body.innerText || '';
        const lumpLines = bodyText.split('\n').filter((l) => /lump\s*sum|conveyance|display board|cess|contingenc/i.test(l));
        for (const l of lumpLines.slice(0, 12)) {
          const numMatch = l.match(/(\d+(?:,\d+)*(?:\.\d+)?)/);
          lumpSums.push({ description: l.trim(), amount: numMatch ? parseFloat(numMatch[1].replace(/,/g, '')) : 0 });
        }
        return { headings, lumpSums };
      }

      async function deleteItemInHeading(headingIndex, code) {
        const row = findHeadingRowByTextOrIndex('', headingIndex);
        if (!row) return { ok: false, message: `Heading #${headingIndex + 1} not found for deletion.` };
        const container = row.parentElement || row;
        const codeUpper = String(code).toUpperCase();
        const rows = Array.from(container.querySelectorAll('tr, li, .item-row, div')).filter(isVisible);
        const match = rows.find((r) => (r.innerText || '').toUpperCase().includes(codeUpper) && r.querySelector('.fa-trash, .bi-trash, button[title*="Delete"], a[title*="Delete"]'));
        if (!match) return { ok: false, message: `Delete icon not found for item ${code}.` };
        const delBtn = match.querySelector('.fa-trash, .bi-trash, button[title*="Delete"], a[title*="Delete"]')?.closest('button, a')
          || match.querySelector('.fa-trash, .bi-trash');
        await clickEl(delBtn);
        return await confirmSwalDelete();
      }

      window.__SECURE_AI_IPAD__ = {
        addHeading,
        addItem,
        fillMeasurements,
        addLumpSum,
        scrapeCurrentEstimate,
        deleteItemInHeading,
        confirmSwalDelete,
        autoFillSecureLogin,
        hideCursor,
        isPortalLoading
      };
      window.__SECURE_AI_IPAD_V9__ = true;
    })();
    """#
}
